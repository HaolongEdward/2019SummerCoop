




import csv

def create_csv(filepath):
    file=open(filepath).read().splitlines()
    length_per_experiment=27
    first_row=["epoch","loss","acc","val_loss","val_acc"]
    data=dict()
    for i in range(int(len(file)/length_per_experiment)):
        numbers=[]
        for j in range(5,24,2):
            temp=[int((j-5)/2)+1,]
            for s in file[i*27+j].split():
                try:
                    x=float(s)
                    temp.append(x)
                except:
                    pass
            numbers.append(temp)
        filename=""+file[i*27+2].split()[2]    
        if filename not in data:
            data[filename]=list()
        data[filename].append(numbers)
        filename=filename+"_"+file[i*27+1].split()[2]
        directory="files/"
        with open(directory+filename+".csv","w") as csvfile:
            filewriter = csv.writer(csvfile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
            filewriter.writerow(first_row)
            for num in numbers:
                filewriter.writerow(num)
        with open(directory+filename+"_test.csv","w") as csvfile:
            filewriter = csv.writer(csvfile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
            filewriter.writerow(["","test_loss","test_acc"])
            filewriter.writerow(["",]+eval(file[i*27+25]))
    for f in data:
        final=[]
        first=data[f][0]
        second=data[f][1]
        thrid=data[f][2]
        for i in range(10):
            temp=[i+1,]
            for j in range(4):
                average=first[i][j+1]+second[i][j+1]+thrid[i][j+1]
                average=average/3
                temp.append(average)
            final.append(temp)
        directory="files/"
        with open(directory+f+".csv","w") as csvfile:
            filewriter = csv.writer(csvfile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
            filewriter.writerow(first_row)
            for row in final:
                filewriter.writerow(row)




def create_csv_general(filepath):
    file=open(filepath).read().splitlines()
    first_row=["epoch","loss","acc","val_loss","val_acc"]
    data=dict()
    temp=list()
    filenames=[]
    for i in range(len(file)):
        if "experiment:" in file[i].split():
            filenames.append(file[i+1].split()[2]+"_"+file[i].split()[2])
            # firstline : !!! experiment: xth .... 
            # second line: Experiment of XXX ...
            data[filenames[-1]]=list()
            if len(temp)!=0:
                data[filenames[-2]]=temp
                temp=list()
        if "loss:" in file[i].split():
            if "ETA:" in file[i].split():  # exclude the case "^M  32/2124 [..............................]....."
                pass
            else:
                numbers=[]
                for s in file[i].split():
                    try:
                        x=float(s)
                        numbers.append(x)
                    except:
                        pass
                temp.append(numbers)
    data[filenames[-1]]=list()
    for name in data:
        with open(name+".csv","w") as csvfile:
            filewriter = csv.writer(csvfile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
            filewriter.writerow(first_row)
            for num in data[name]:
                filewriter.writerow(num)


    
#create_csv_general("test_r.txt")
























